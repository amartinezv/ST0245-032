

import java.util.Random;
import java.util.concurrent.TimeUnit;
public class Punto1
{
    public static void main(String[] args){
        for(int i = 1; i <= 30000000; i = i+1){
            System.out.println("suma "+i+" "+ tomarElTiempoParaN(i)); 
        }
    }

    public static int arraySum(int [] A){
        int suma = 0;
        for(int i = 0; i < A.length; i++){
            suma =+A[i];
        }
        try{
            TimeUnit.SECONDS.sleep(1);
        }catch(InterruptedException ex){
            Thread.currentThread().interrupt();
        }
        return suma;
    }

    public static long tomarElTiempoParaN(int n){
        int[] arreglo = crearUnArregloAleatorio(n);
        long startTime = System.currentTimeMillis();
        arraySum(arreglo);
        long estimatedTime = System.currentTimeMillis() - startTime;
        return estimatedTime;
    }

    public static int[] crearUnArregloAleatorio(int n){
        int max = 5000;
        int[] array = new int[n];
        Random generator = new Random();
        for(int i = 0; i < n; i++){
            array[i] = generator.nextInt(max);
        }
        return array;
    }

}