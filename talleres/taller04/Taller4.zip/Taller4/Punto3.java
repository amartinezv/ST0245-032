
import java.util.Random;
import java.util.concurrent.TimeUnit;
public class Punto3
{
     public static void main(String[] args){
        for(int i = 1000; i <= 1000000; i = i+1){
            System.out.println("ordenamiento por insercion "+i+" "+ tomarElTiempoParaN(i)); 
        }
    }
    
    public static int[] ordenar(int[]A){
        int temp;
        for(int i = 0; i < A.length-1; i++){
            for(int j = i+1; j < A.length; j++){
                if(A[j] < A[i]){
                    temp = A[i];
                    A[i] = A[j];
                    A[j] = temp;
                }
            }
        }
        return A;
    }
    
    public static int[] crearUnArregloAleatorio(int n){
        int max = 5000;
        int[] array = new int[n];
        Random generator = new Random();
        for(int i = 0; i < n; i++){
            array[i] = generator.nextInt(max);
        }
        return array;
    }
    
     public static long tomarElTiempoParaN(int n){
        int[] arreglo = crearUnArregloAleatorio(n);
        long startTime = System.currentTimeMillis();
        ordenar(arreglo);
        long estimatedTime = System.currentTimeMillis() - startTime;
        return estimatedTime;
    }
}
