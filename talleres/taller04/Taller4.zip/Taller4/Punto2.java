
import java.util.concurrent.TimeUnit;
public class Punto2
{
    public static void main(String[] args){
         for(int i = 1; i <= 30; i = i+1){
            System.out.println("Timpo "+ tomarElTiempoParaN(i)); 
        }
    }
    
    public static int  tablas(int n){
        int a=0;
        for(int i = 0; i <= n; i++){
            for(int j = 0; j <= n; j++){
               String s = (i +" * "+j+" = "+j*i);
               System.out.println(s);
                a = i*j;
            }
        }
        return a;
    }
    
    public static long tomarElTiempoParaN(int n){
        int tabla = tablas(n);
        long startTime = System.currentTimeMillis();
        tablas(tabla);
        long estimatedTime = System.currentTimeMillis() - startTime;
        return estimatedTime;
    }
}
